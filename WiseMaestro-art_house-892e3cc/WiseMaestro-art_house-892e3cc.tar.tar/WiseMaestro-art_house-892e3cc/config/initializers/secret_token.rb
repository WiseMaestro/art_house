# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ArtHouse::Application.config.secret_token = '4034ff96ff6c929d3514d376198d1efdeaadf2d1792c014c5b51c8fe369b4e2939734c934c9faab1666941529435551a3b349e22c99ad7ccb211a5028944f61f'
